
/**
 * Write a description of interface Attack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Attack
{
    String attack();
}
