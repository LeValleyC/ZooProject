
/**
 * Write a description of class AnimalTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AnimalTester
{
    public static void main(String[] args) 
    {
        Animal b = new CircusBear();
        b.interact();
        
        Animal banana = new GermanShepard();
        banana.eat();
    }
}
