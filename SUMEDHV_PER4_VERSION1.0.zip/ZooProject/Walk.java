public interface Walk {
    String walk();
}