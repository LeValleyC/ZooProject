public interface Swim {
    //if you want to swim, you must define the 
    //following methods:
    
    //Since ALL methods in Interfaces are public
    //and abstract by default, we save keystrokes
    //by not writing public & abstract
    String swim();
    //you also could have written:
    //public abstract String swim();
    //but the public & abstract are redundant
    //that's redundant and redundant.
}