public interface Fly {
    String fly();
}